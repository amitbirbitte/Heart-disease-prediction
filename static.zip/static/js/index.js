const totalSteps = 13;
let currentStep = 1;

const images = {
  1: "/static/images/step1.png",
  2: "/static/images/step2.png",
  3: "/static/images/step3.png",
  4: "/static/images/step4.avif",
  5: "/static/images/step5.png",
  6: "/static/images/step6.png",
  7: "/static/images/step7.png",
  8: "/static/images/step8.png",
  9: "/static/images/step9.png",
  10: "/static/images/step10.png",
  11: "/static/images/step11.png",
  12: "/static/images/step12.png",
  13: "/static/images/step13.png"
};

function showStep(step) {
  if (step < 1) step = 1;
  if (step > totalSteps) step = totalSteps;

  document.querySelectorAll(".fade-section").forEach((section, idx) => {
    section.classList.toggle("active", idx === step - 1);
  });

  document.getElementById("prevBtn").disabled = step === 1;
  document.getElementById("nextBtn").textContent = step === totalSteps ? "Predict Result" : "Next";

  const img = document.getElementById("stepImage");
  img.classList.add("fade-out");
  setTimeout(() => {
    img.src = images[step];
    img.classList.remove("fade-out");
  }, 250);
}

async function changeStep(n) {
  if (currentStep === totalSteps && n === 1) {
    const form = document.getElementById("predictionForm");
    const formData = new FormData(form);
    fetch("/predict_page", {
      method: "POST",
      body: formData
    }).then(response => response.text())
      .then(html => {
        document.open();
        document.write(html);
        document.close();
      });
    return;
  }

  currentStep += n;
  showStep(currentStep);
}

document.addEventListener("DOMContentLoaded", () => showStep(currentStep));
